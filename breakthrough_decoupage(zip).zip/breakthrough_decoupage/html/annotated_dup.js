var annotated_dup =
[
    [ "Case", "struct_case.html", null ],
    [ "Coup", "struct_coup.html", null ],
    [ "Joueur", "struct_joueur.html", null ],
    [ "Partie", "struct_partie.html", null ]
];