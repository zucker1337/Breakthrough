var coup_8c =
[
    [ "afficherRefus", "coup_8c.html#abbd84045f24bceb735ac7f6e998964c3", null ],
    [ "verifierCoup", "coup_8c.html#a0ebaab1edbc5284bf40d64a735a993d3", null ]
];