/*
 @licstart  The following is the entire license notice for the JavaScript code in this file.

 The MIT License (MIT)

 Copyright (C) 1997-2020 by Dimitri van Heesch

 Permission is hereby granted, free of charge, to any person obtaining a copy of this software
 and associated documentation files (the "Software"), to deal in the Software without restriction,
 including without limitation the rights to use, copy, modify, merge, publish, distribute,
 sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:

 The above copyright notice and this permission notice shall be included in all copies or
 substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

 @licend  The above is the entire license notice for the JavaScript code in this file
*/
var NAVTREE =
[
  [ "Jeu de plateau", "index.html", [
    [ "Changelog", "md__c_h_a_n_g_e_l_o_g.html", [
      [ "Semaine 4 &ndash; 19/10/26", "md__c_h_a_n_g_e_l_o_g.html#autotoc_md1", [
        [ "Modifié", "md__c_h_a_n_g_e_l_o_g.html#autotoc_md2", null ],
        [ "Corrigé", "md__c_h_a_n_g_e_l_o_g.html#autotoc_md3", null ]
      ] ],
      [ "Semaine 3 &ndash; 16/10/26", "md__c_h_a_n_g_e_l_o_g.html#autotoc_md4", [
        [ "Ajouté", "md__c_h_a_n_g_e_l_o_g.html#autotoc_md5", null ],
        [ "Modifié", "md__c_h_a_n_g_e_l_o_g.html#autotoc_md6", null ],
        [ "Corrigé", "md__c_h_a_n_g_e_l_o_g.html#autotoc_md7", null ]
      ] ],
      [ "Semaine 2 &ndash; 09/10/26", "md__c_h_a_n_g_e_l_o_g.html#autotoc_md8", [
        [ "Ajouté", "md__c_h_a_n_g_e_l_o_g.html#autotoc_md9", null ],
        [ "Modifié", "md__c_h_a_n_g_e_l_o_g.html#autotoc_md10", null ],
        [ "Corrigé", "md__c_h_a_n_g_e_l_o_g.html#autotoc_md11", null ]
      ] ],
      [ "Semaine 1 &ndash; 02/10/26", "md__c_h_a_n_g_e_l_o_g.html#autotoc_md12", [
        [ "Ajouté", "md__c_h_a_n_g_e_l_o_g.html#autotoc_md13", null ]
      ] ]
    ] ],
    [ "Breakthrough", "md__r_e_a_d_m_e.html", [
      [ "Description", "md__r_e_a_d_m_e.html#autotoc_md19", null ],
      [ "Compilation et exécution", "md__r_e_a_d_m_e.html#autotoc_md20", null ],
      [ "Schéma de décomposition", "md__r_e_a_d_m_e.html#autotoc_md21", [
        [ "Représentation du plateau", "md__r_e_a_d_m_e.html#autotoc_md22", null ],
        [ "Les informations du jeu", "md__r_e_a_d_m_e.html#autotoc_md23", null ],
        [ "Fonctions réalisées (semaine 3)", "md__r_e_a_d_m_e.html#autotoc_md24", null ],
        [ "Décomposition prévue (fin de projet)", "md__r_e_a_d_m_e.html#autotoc_md25", null ]
      ] ],
      [ "Organisation du projet", "md__r_e_a_d_m_e.html#autotoc_md26", null ],
      [ "Documentation", "md__r_e_a_d_m_e.html#autotoc_md27", null ],
      [ "Jeux d'essais", "md__r_e_a_d_m_e.html#autotoc_md28", null ],
      [ "Journal des changements", "md__r_e_a_d_m_e.html#autotoc_md29", null ],
      [ "Licences", "md__r_e_a_d_m_e.html#autotoc_md30", null ]
    ] ],
    [ "Classes", "annotated.html", [
      [ "Liste des classes", "annotated.html", "annotated_dup" ],
      [ "Index des classes", "classes.html", null ]
    ] ],
    [ "Fichiers", "files.html", [
      [ "Liste des fichiers", "files.html", "files_dup" ],
      [ "Membres de fichier", "globals.html", [
        [ "Tout", "globals.html", null ],
        [ "Fonctions", "globals_func.html", null ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"annotated.html"
];

const SYNCONMSG = 'cliquez pour désactiver la synchronisation du panel';
const SYNCOFFMSG = 'cliquez pour activer la synchronisation du panel';
const LISTOFALLMEMBERS = 'Liste de tous les membres';