var files_dup =
[
    [ "case.c", "case_8c.html", "case_8c" ],
    [ "case.h", "case_8h_source.html", null ],
    [ "coup.c", "coup_8c.html", "coup_8c" ],
    [ "coup.h", "coup_8h_source.html", null ],
    [ "gagnant.c", "gagnant_8c.html", null ],
    [ "gagnant.h", "gagnant_8h_source.html", null ],
    [ "jeu.c", "jeu_8c.html", null ],
    [ "joueur.c", "joueur_8c.html", null ],
    [ "joueur.h", "joueur_8h_source.html", null ],
    [ "partie.c", "partie_8c.html", null ],
    [ "partie.h", "partie_8h_source.html", null ],
    [ "plateau.c", "plateau_8c.html", null ],
    [ "plateau.h", "plateau_8h_source.html", null ],
    [ "regles.c", "regles_8c.html", "regles_8c" ],
    [ "regles.h", "regles_8h.html", "regles_8h" ]
];