var indexSectionsWithContent =
{
  0: "01234abcdefgijlmnoprsv",
  1: "cjp",
  2: "cgjpr",
  3: "alv",
  4: "01234abcdefijlmnoprs"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "pages"
};

var indexSectionLabels =
{
  0: "Tout",
  1: "Classes",
  2: "Fichiers",
  3: "Fonctions",
  4: "Pages"
};

