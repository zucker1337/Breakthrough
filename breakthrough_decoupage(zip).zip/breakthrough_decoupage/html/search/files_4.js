var searchData=
[
  ['regles_2ec_0',['regles.c',['../regles_8c.html',1,'']]],
  ['regles_2eh_1',['regles.h',['../regles_8h.html',1,'']]]
];
