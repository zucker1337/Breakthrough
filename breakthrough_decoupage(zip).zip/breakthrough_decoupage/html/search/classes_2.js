var searchData=
[
  ['partie_0',['Partie',['../struct_partie.html',1,'']]]
];
