var searchData=
[
  ['case_0',['Case',['../struct_case.html',1,'']]],
  ['coup_1',['Coup',['../struct_coup.html',1,'']]]
];
